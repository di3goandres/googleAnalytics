# desarrollo 
# server = '192.168.1.150' 

# database = 'analytics' 
# username = 'sa' 
# password = 'MariaJose2110' 
# VIEW_ID = "174979889"
# KEY_FILE_LOCATION = "client.json"


#pruebas

server = 'serversql2014.margenceropi.com,49610' 

database = 'vue_v12' 
username = 'usrVUE' 
password = 'UsrVUE12#$' 
VIEW_ID = "174979889"
KEY_FILE_LOCATION = "client.json"